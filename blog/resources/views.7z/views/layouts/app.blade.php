<!doctype html>
<html>
    <head>
       <title>Magazines</title>
    </head>
    <body>
        @yield('main')
    </body>
</html>
